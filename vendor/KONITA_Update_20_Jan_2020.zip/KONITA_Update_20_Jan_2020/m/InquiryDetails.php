<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InquiryDetails extends Model {

    protected $primaryKey = 'id';
    protected $table = 'inquiry_details';
    public $timestamps = false;

    public static function boot() {
        parent::boot();
    }

}
